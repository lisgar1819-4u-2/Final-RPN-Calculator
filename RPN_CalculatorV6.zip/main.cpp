/***************************************************

Bin (Quoc Dat Phung)
Teacher: Ms. Lindsay Cullum
Date: April 11, 2019

    STACK files for RPN Calculator
    Linked List is used
***************************************************/

#include <iostream>
using namespace std;
#include <memory>
#include <string>
#include <iomanip>
#include "method.h"

///Prototypes
void fixed_Decimal_Place();
void displayOut(method list);
void introduction();


int main () {
    //declaring variables
    string option = "0";
    string calculate;
    float input = 0;

    //declaring linked list
    method list;
    Node *head = new Node;
    Node *tail = new Node;

    //two decimals only (see below main)
    fixed_Decimal_Place();

    ///INPUT
    introduction(); //guide for user

    ///OUTPUT
    while (option != "n") {

        cout << "\n--------------------------------------------------------\n";
        cout << "(u)push (o)pop (+)add (-)subtract (*)multiply (/)divide:" << endl;
        cout << "Enter: ";
        cin >> calculate;
        cout << endl;

        if (calculate == "u")
        {
            cout << "Enter number to push: ";
            cin >> input;
            list.pushNode(input);
            displayOut(list);

        } else if (calculate == "o") {
            list.popNode();
            displayOut(list);   //function see below main

        } else if (calculate == "+") {
            list.addNode();
            displayOut(list);   //function see below main

        } else if (calculate == "-") {
            list.subtractNode();
            displayOut(list);   //function see below main

        } else if (calculate == "*") {
            list.multiplyNode();
            displayOut(list);   //function see below main

        } else if (calculate == "/") {
            list.divideNode();
            displayOut(list);   //function see below main

        } else {
            cout << "Unknown calculation" << endl;
        }

        cout << "Continue(y/n):";
        cin >> option;


        if (option != "y" && option != "n")
        {
            cout << "Unknown Option... Assume you continue." << endl;
        }


        if (option == "n") {
        break;
        }

    }

list.deleteNode();
return 0;
}

void fixed_Decimal_Place() {
    //code from textbook, but I already know
    cout << setprecision(2);
    cout.setf(ios::showpoint | ios::fixed);
    cout.setf(ios::right, ios::adjustfield);
}

void displayOut(method list)
{
    cout << endl;
    list.displayNode();
    cout << endl;
}

void introduction()
{
    cout << "Welcome to Bin's RPN calculator! ";
    cout << "It uses linked list stacks to do numerical calculations." << endl;
}
