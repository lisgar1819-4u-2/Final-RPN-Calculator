#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

struct Node
{
    float data;
    Node*next;
};

class STACK {


public:
    ///CONSTRUCTORS
    STACK();


    ///DESTRUCTOR
    ~STACK();


    ///METHODS
    //print array
    void display();
    //check if array is empty
    bool isEmpty();
    //check if array is full
    bool isFull();

    //set "top" with a number
    void setTop(int t);
    //get value of "top"
    int getTop() const {return top;};
    //change value of size;
    void setSize(int s);
    //get value of size;
    int getSize() const {return size;};
    //push n into stack
    void push(float n);
    //pop n from stack
    float pop();
    //set and get TopNode
    void setTopNode(int t) {topNode = t;};
    int getTopNode() const {return topNode;};
    //check if linked list is "empty"
    bool isEmptyNode();
    //push numbers into linked list
    void pushNode(float n);
    //pop numbers from linked list
    float popNode();
    //display linked list
    void displayNode();
    //delete linked list
    void deleteNode();










    float stack[20];






private:
    int top;
    int size;
    Node *head, *tail, *temp, *newnode;
    int topNode;

};


#endif STACK_H_INCLUDED



