#include <iostream>
using namespace std;


#include "method.h"

///DEFINITIONS OF CONSTRUCTORS
method::method(){
    STACK();
}

method::~method(){
//cout << "Deleting Object..." << endl;
}


void method::add()
{
    //receive the top 2 numbers
    //from popping; top returns int
    //perform calculation
    //get result, then push result
    float a, b;
    if (!isEmpty())
    {
        a = pop();
        b = pop();
        push(b+a);
    }
}


void method::addNode()
{
 //same implementation
    float a, b;

    if (!isEmptyNode())
    {
        a = popNode();
        b = popNode();
        pushNode(b+a);
    }
}

void method::subtract()
{
    //receive the top 2 numbers
    //from popping; top returns int
    //perform calculation
    //get result, then push result
    float a, b;
    if (!isEmpty())
    {
        a=pop();
        b=pop();
        push(b-a);
    }
}

void method::subtractNode()
{
 //same implementation
    float a, b;

    if (!isEmptyNode())
    {
        a = popNode();
        b = popNode();
        pushNode(b-a);
    }
}

void method::multiply()
{
    //receive the top 2 numbers
    //from popping; top returns int
    //perform calculation
    //get result, then push result
    float a, b;
    if (!isEmpty())
    {
        a=pop();
        b=pop();
        push(b*a);
    }
}

void method::multiplyNode()
{
 //same implementation
    float a, b;

    if (!isEmptyNode())
    {
        a = popNode();
        b = popNode();
        pushNode(b*a);
    }
}

void method::divide()
{
    //receive the top 2 numbers
    //from popping; top returns int
    //perform calculation
    //get result, then push result
    float a, b;
    if (!isEmpty())
    {
        a=pop();
        b=pop();
        push(b/a);
    }
}

void method::divideNode()
{
 //same implementation
    float a, b;

    if (!isEmptyNode())
    {
        a = popNode();
        b = popNode();
        pushNode(b/a);
    }
}





