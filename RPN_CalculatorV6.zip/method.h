
#ifndef METHOD_H_INCLUDED
#define METHOD_H_INCLUDED

#include "stack.h"


class method : public STACK
{ // Student inherits the Person class


    public:
        method();
        ~method();

        //add elements in stack array
        void add();
        //subtract elements in stack array
        void subtract();
        //multiply elements in stack array
        void multiply();
        //divide elements in stack array
        void divide();
        //calculation linked list
        void addNode();
        void subtractNode();
        void multiplyNode();
        void divideNode();

};



#endif // METHOD_H_INCLUDED
