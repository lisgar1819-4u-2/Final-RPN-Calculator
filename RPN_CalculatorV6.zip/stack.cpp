#include <iostream>
using namespace std;

#include <cmath>
#include "stack.h"




///DEFINITIONS OF CONSTRUCTORS
STACK::STACK(){

    setSize(5);
    for (int i = 0; i < getSize(); i++)
    {
        stack[i] = 0;
    }
    setTop(-1);

    //_________________ Node declaration:
    setTopNode(-1);
    head = NULL;
    tail = NULL;

}

STACK::~STACK(){
//cout << "Deleting Object..." << endl;
}

///METHODS
void STACK::display() {
//display starting at variable "top"
//print until top is 0;
    for (int i = getTop(); i >= 0; i--)
    {
        cout << stack[i] << endl;
    }
}

bool STACK::isEmpty()
{
    if (getTop() == -1)
    {
        return true;  //is empty
    } else {
        return false; // is not empty
    }
}

bool STACK::isEmptyNode()
{
    if (getTopNode() == -1)
    {
        return true;  //stack has no nodes
    } else {
        return false; //stack has nodes
    }
}


bool STACK::isFull()
{
    if (getTop() == getSize())
    {
        return true;    //is full
    } else {
        return false;   //not full
    }
    ///linked list is never full!!
    //it's not an array
    //we can push how many times we want.
}

void STACK::setTop(int t)
{
    top = t;
}

void STACK::setSize(int s)
{
    size = s;
}

void STACK::push(float n)
{
//push method from assignment package
//if it's not full, then top increments
//so the number/element can be pushed in that
//new index.
    if (!isFull())
    {
        setTop(getTop()+1);
        stack[top] = n;
    } else {
        cout << "\nStack's Full.\n";
    }
}

void STACK::pushNode(float n)
{
    //push a new node
    newnode = new Node;
    //user pushes number
    //so number is put into
    //new node's data
    newnode->data = n;
    //insert node at the BEGINNING
    //that's where the top of the
    //linked list is.
    newnode->next = head;
    //make newnode the head.
    head = newnode;
    //increment top
    setTopNode(getTopNode()+1);
}

float STACK::pop()
{
//pop method from assignment
//if it's not empty, then pop is possible
//so top decreases by 1 and returns that number
    float n;
    if (!isEmpty())
    {
        n = stack[getTop()];
        setTop(getTop()-1);
        return n;
    } else {
        cout << "\nStack's Empty.\n";
        return 404;
    }
}

float STACK::popNode()
{

    float n;
    if (!isEmptyNode() && head != NULL)
    {

        temp = head;
        n = temp->data;
        //move head to next element
        //to exclude the top element

        head = head->next;
        //delete top element
        delete temp;
        //top decrements
        setTopNode(getTopNode()-1);
        return n;
    } else {
        cout << "\nLinked List's Empty.\n";
        return 404;
    }
}

void STACK::displayNode() {
//display starting at variable "top"
//print until top is 0;
   // temp = new Node;
    temp = head;
    for (int i = getTopNode(); i >= 0; i--)
    {
        while (temp!=NULL)
        {
            cout << temp->data << endl;
            temp = temp->next;
        }
    }
}


void STACK::deleteNode(){

    for (int i = 0; i<getTopNode(); i++)
    {
            popNode();

            if (head == NULL)
            {
                break;
            }
        }

    }

    //cout << endl << getTopNode();



